﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem.Reports
{
    public partial class StaffReport : UserControl
    {
        public StaffReport()
        {
            InitializeComponent();
        }

        private void reportBtn_Click(object sender, EventArgs e)
        {
            int id = reportsTableAdapter.GetData().Select().Length;
            string report = staffReportBox.Text;
            reportsTableAdapter.Insert(id, 1731274, report);

            ListBox reportListBox = reportList;
            reportListBox.Items.Add(report);
        }

        private void reportsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.reportsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.storeDataSet);

        }

        private void reportsBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.reportsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.storeDataSet);

        }

        private void StaffReport_Load(object sender, EventArgs e)
        {
            DataRow[] rowList = reportsTableAdapter.GetData().Select();
            ListBox reportListBox = reportList;

            for (int i = 0; i < rowList.Length; i++)
            {
                object[] entry = rowList.ElementAt(i).ItemArray;
                string selectedReport = entry[2].ToString();

                reportListBox.Items.Add(selectedReport);
            }
        }
    }
}
