﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem.Reports
{
    public partial class ProductQuantityAlert : UserControl
    {
        List<Label> labels = new List<Label>();
        public ProductQuantityAlert()
        {
            InitializeComponent();
        }

        private void ProductQuantityAlert_Load(object sender, EventArgs e)
        {
            labels.Add(product1Name);
            labels.Add(product1Quantity);
            labels.Add(product2Name);
            labels.Add(product2Quantity);
            labels.Add(product3Name);
            labels.Add(product3Quantity);
            labels.Add(product4Name);
            labels.Add(product4Quantity);
            labels.Add(product5Name);
            labels.Add(product5Quantity);

            DataRow[] rowList = storeTableAdapter.GetData().Select();
            var sortedList = rowList.OrderBy(row => row[4]);

            int k = 0;
            for (int i = 0; i < rowList.Length; i++)
            {
                //object[] entry = rowList.ElementAt(i).ItemArray;
                object[] entry = sortedList.ElementAt(i).ItemArray; 

                if (k <= 9)
                {
                    labels[k].Text = entry[1].ToString();
                    labels[k + 1].Text = entry[4].ToString();
                    k += 2;
                }
            }

        }

        private void storeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.storeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.storeDataSet);
        }
    }
}
