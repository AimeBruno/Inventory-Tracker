﻿namespace AkhavanDatabaseSystem.Reports
{
    partial class StaffReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.welcomeUserLabel = new System.Windows.Forms.Label();
            this.staffReportBox = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.reportBtn = new System.Windows.Forms.Button();
            this.reportList = new System.Windows.Forms.ListBox();
            this.storeDataSet = new AkhavanDatabaseSystem.StoreDataSet();
            this.reportsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportsTableAdapter = new AkhavanDatabaseSystem.StoreDataSetTableAdapters.ReportsTableAdapter();
            this.tableAdapterManager = new AkhavanDatabaseSystem.StoreDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.storeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // welcomeUserLabel
            // 
            this.welcomeUserLabel.AutoSize = true;
            this.welcomeUserLabel.BackColor = System.Drawing.SystemColors.Window;
            this.welcomeUserLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeUserLabel.Location = new System.Drawing.Point(120, 14);
            this.welcomeUserLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.welcomeUserLabel.Name = "welcomeUserLabel";
            this.welcomeUserLabel.Size = new System.Drawing.Size(174, 32);
            this.welcomeUserLabel.TabIndex = 8;
            this.welcomeUserLabel.Text = "Staff Report";
            // 
            // staffReportBox
            // 
            this.staffReportBox.Location = new System.Drawing.Point(23, 58);
            this.staffReportBox.Name = "staffReportBox";
            this.staffReportBox.Size = new System.Drawing.Size(326, 44);
            this.staffReportBox.TabIndex = 9;
            this.staffReportBox.Text = "";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // reportBtn
            // 
            this.reportBtn.Location = new System.Drawing.Point(274, 109);
            this.reportBtn.Name = "reportBtn";
            this.reportBtn.Size = new System.Drawing.Size(75, 23);
            this.reportBtn.TabIndex = 12;
            this.reportBtn.Text = "Submit";
            this.reportBtn.UseVisualStyleBackColor = true;
            this.reportBtn.Click += new System.EventHandler(this.reportBtn_Click);
            // 
            // reportList
            // 
            this.reportList.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportList.FormattingEnabled = true;
            this.reportList.ItemHeight = 20;
            this.reportList.Location = new System.Drawing.Point(23, 140);
            this.reportList.Name = "reportList";
            this.reportList.Size = new System.Drawing.Size(326, 204);
            this.reportList.TabIndex = 13;
            // 
            // storeDataSet
            // 
            this.storeDataSet.DataSetName = "StoreDataSet";
            this.storeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportsBindingSource
            // 
            this.reportsBindingSource.DataMember = "Reports";
            this.reportsBindingSource.DataSource = this.storeDataSet;
            // 
            // reportsTableAdapter
            // 
            this.reportsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ReportsTableAdapter = this.reportsTableAdapter;
            this.tableAdapterManager.StoreTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = AkhavanDatabaseSystem.StoreDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // StaffReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.Controls.Add(this.reportList);
            this.Controls.Add(this.reportBtn);
            this.Controls.Add(this.staffReportBox);
            this.Controls.Add(this.welcomeUserLabel);
            this.Name = "StaffReport";
            this.Size = new System.Drawing.Size(381, 369);
            this.Load += new System.EventHandler(this.StaffReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.storeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeUserLabel;
        private System.Windows.Forms.RichTextBox staffReportBox;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button reportBtn;
        private System.Windows.Forms.ListBox reportList;
        private StoreDataSet storeDataSet;
        private System.Windows.Forms.BindingSource reportsBindingSource;
        private StoreDataSetTableAdapters.ReportsTableAdapter reportsTableAdapter;
        private StoreDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}
