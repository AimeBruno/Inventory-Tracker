﻿namespace AkhavanDatabaseSystem.Reports
{
    partial class ProductQuantityAlert
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.welcomeUserLabel = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.product5Name = new System.Windows.Forms.Label();
            this.product5Quantity = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.product1Name = new System.Windows.Forms.Label();
            this.product1Quantity = new System.Windows.Forms.Label();
            this.product2Name = new System.Windows.Forms.Label();
            this.product2Quantity = new System.Windows.Forms.Label();
            this.product3Name = new System.Windows.Forms.Label();
            this.product3Quantity = new System.Windows.Forms.Label();
            this.product4Name = new System.Windows.Forms.Label();
            this.product4Quantity = new System.Windows.Forms.Label();
            this.storeDataSet = new AkhavanDatabaseSystem.StoreDataSet();
            this.storeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.storeTableAdapter = new AkhavanDatabaseSystem.StoreDataSetTableAdapters.StoreTableAdapter();
            this.tableAdapterManager = new AkhavanDatabaseSystem.StoreDataSetTableAdapters.TableAdapterManager();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.storeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // welcomeUserLabel
            // 
            this.welcomeUserLabel.AutoSize = true;
            this.welcomeUserLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeUserLabel.Location = new System.Drawing.Point(44, 17);
            this.welcomeUserLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.welcomeUserLabel.Name = "welcomeUserLabel";
            this.welcomeUserLabel.Size = new System.Drawing.Size(309, 32);
            this.welcomeUserLabel.TabIndex = 8;
            this.welcomeUserLabel.Text = "Product Quantity Alert";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.7451F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.2549F));
            this.tableLayoutPanel1.Controls.Add(this.product5Name, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.product5Quantity, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.product1Name, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.product1Quantity, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.product2Name, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.product2Quantity, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.product3Name, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.product3Quantity, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.product4Name, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.product4Quantity, 1, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(13, 64);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.08696F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.91304F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(357, 283);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // product5Name
            // 
            this.product5Name.AutoSize = true;
            this.product5Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product5Name.Location = new System.Drawing.Point(2, 239);
            this.product5Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product5Name.Name = "product5Name";
            this.product5Name.Size = new System.Drawing.Size(129, 27);
            this.product5Name.TabIndex = 20;
            this.product5Name.Text = "Product #1";
            this.product5Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product5Quantity
            // 
            this.product5Quantity.AutoSize = true;
            this.product5Quantity.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product5Quantity.Location = new System.Drawing.Point(226, 239);
            this.product5Quantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product5Quantity.Name = "product5Quantity";
            this.product5Quantity.Size = new System.Drawing.Size(38, 27);
            this.product5Quantity.TabIndex = 21;
            this.product5Quantity.Text = "10";
            this.product5Quantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(226, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 27);
            this.label2.TabIndex = 9;
            this.label2.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Product Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // product1Name
            // 
            this.product1Name.AutoSize = true;
            this.product1Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product1Name.Location = new System.Drawing.Point(2, 47);
            this.product1Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product1Name.Name = "product1Name";
            this.product1Name.Size = new System.Drawing.Size(129, 27);
            this.product1Name.TabIndex = 10;
            this.product1Name.Text = "Product #1";
            this.product1Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product1Quantity
            // 
            this.product1Quantity.AutoSize = true;
            this.product1Quantity.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product1Quantity.Location = new System.Drawing.Point(226, 47);
            this.product1Quantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product1Quantity.Name = "product1Quantity";
            this.product1Quantity.Size = new System.Drawing.Size(38, 27);
            this.product1Quantity.TabIndex = 11;
            this.product1Quantity.Text = "10";
            this.product1Quantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product2Name
            // 
            this.product2Name.AutoSize = true;
            this.product2Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product2Name.Location = new System.Drawing.Point(2, 92);
            this.product2Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product2Name.Name = "product2Name";
            this.product2Name.Size = new System.Drawing.Size(129, 27);
            this.product2Name.TabIndex = 14;
            this.product2Name.Text = "Product #1";
            this.product2Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product2Quantity
            // 
            this.product2Quantity.AutoSize = true;
            this.product2Quantity.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product2Quantity.Location = new System.Drawing.Point(226, 92);
            this.product2Quantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product2Quantity.Name = "product2Quantity";
            this.product2Quantity.Size = new System.Drawing.Size(38, 27);
            this.product2Quantity.TabIndex = 15;
            this.product2Quantity.Text = "10";
            this.product2Quantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product3Name
            // 
            this.product3Name.AutoSize = true;
            this.product3Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product3Name.Location = new System.Drawing.Point(2, 138);
            this.product3Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product3Name.Name = "product3Name";
            this.product3Name.Size = new System.Drawing.Size(129, 27);
            this.product3Name.TabIndex = 16;
            this.product3Name.Text = "Product #1";
            this.product3Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product3Quantity
            // 
            this.product3Quantity.AutoSize = true;
            this.product3Quantity.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product3Quantity.Location = new System.Drawing.Point(226, 138);
            this.product3Quantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product3Quantity.Name = "product3Quantity";
            this.product3Quantity.Size = new System.Drawing.Size(38, 27);
            this.product3Quantity.TabIndex = 17;
            this.product3Quantity.Text = "10";
            this.product3Quantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product4Name
            // 
            this.product4Name.AutoSize = true;
            this.product4Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product4Name.Location = new System.Drawing.Point(2, 188);
            this.product4Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product4Name.Name = "product4Name";
            this.product4Name.Size = new System.Drawing.Size(129, 27);
            this.product4Name.TabIndex = 18;
            this.product4Name.Text = "Product #1";
            this.product4Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // product4Quantity
            // 
            this.product4Quantity.AutoSize = true;
            this.product4Quantity.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product4Quantity.Location = new System.Drawing.Point(226, 188);
            this.product4Quantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.product4Quantity.Name = "product4Quantity";
            this.product4Quantity.Size = new System.Drawing.Size(38, 27);
            this.product4Quantity.TabIndex = 19;
            this.product4Quantity.Text = "10";
            this.product4Quantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // storeDataSet
            // 
            this.storeDataSet.DataSetName = "StoreDataSet";
            this.storeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // storeBindingSource
            // 
            this.storeBindingSource.DataMember = "Store";
            this.storeBindingSource.DataSource = this.storeDataSet;
            // 
            // storeTableAdapter
            // 
            this.storeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.StoreTableAdapter = this.storeTableAdapter;
            this.tableAdapterManager.UpdateOrder = AkhavanDatabaseSystem.StoreDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // ProductQuantityAlert
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.welcomeUserLabel);
            this.Name = "ProductQuantityAlert";
            this.Size = new System.Drawing.Size(389, 372);
            this.Load += new System.EventHandler(this.ProductQuantityAlert_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.storeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeUserLabel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label product1Name;
        private System.Windows.Forms.Label product1Quantity;
        private System.Windows.Forms.Label product5Name;
        private System.Windows.Forms.Label product5Quantity;
        private System.Windows.Forms.Label product2Name;
        private System.Windows.Forms.Label product2Quantity;
        private System.Windows.Forms.Label product3Name;
        private System.Windows.Forms.Label product3Quantity;
        private System.Windows.Forms.Label product4Name;
        private System.Windows.Forms.Label product4Quantity;
        private StoreDataSet storeDataSet;
        private System.Windows.Forms.BindingSource storeBindingSource;
        private StoreDataSetTableAdapters.StoreTableAdapter storeTableAdapter;
        private StoreDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}
