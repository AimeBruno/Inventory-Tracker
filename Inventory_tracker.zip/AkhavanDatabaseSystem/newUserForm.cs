﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class NewUserForm : Form
    {

        //Variables to hold strings entered by the user
        private string oldPassword, newPassword, confirmPassword, originalPassword,
            userName;

        public NewUserForm()
        {
            InitializeComponent();
        }

        private void NewUserForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'loginDataSet.Login' table. You can move, or remove it, as needed.
            this.loginTableAdapter.Fill(this.loginDataSet.Login);

        }

        //Change Password Handler
        private void changePasswordButton_Click(object sender, EventArgs e)
        {

            oldPassword = oldPasswordTextBox.Text;
            newPassword = newPassWordTextBox.Text;
            confirmPassword = confirmPasswordTextBox.Text;

            //Password and username ented in the login page
            originalPassword = LogInUserControl.PassWord;
            userName = LogInUserControl.Username;

            //Check that the value of old password entered matches 
            //that of the password entered in the login page
            //Display error message on the screen if they don't match
            if (!oldPassword.Equals(originalPassword))
            {
                newUserErrorLabel.Text = "Incorrect old password.";
            }
            else
            {
                if (!newPassword.Equals(confirmPassword))
                {
                    /*Display an error if the new password value does not match
                      The value in comfirm password text box */
                    newUserErrorLabel.Text = "Passwords do not match.";
                }
                else
                {
                    /*If both password values match, update the password in the 
                      database and advise the user that changes were done*/
                    newUserErrorLabel.ForeColor = Color.Green;
                    newUserErrorLabel.Text = " Succesfull password change!";

                    this.loginTableAdapter.passwordUpdate(newPassword, userName);
                }
            }
        }

        //Exit button handler
        //Saves the changes made in the database 
        //Close the form and returns user to the login form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.tableAdapterManager.UpdateAll(this.loginDataSet);
            this.loginTableAdapter.Update(this.loginDataSet.Login);
            LogInUserControl.Username = LogInUserControl.Username;
            var loginForm = new LogInForm();
            loginForm.Show();
            this.Close();
        }
    }
}
