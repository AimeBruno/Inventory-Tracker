﻿namespace AkhavanDatabaseSystem
{
    partial class LogInUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.userPictureBoz = new System.Windows.Forms.PictureBox();
            this.memberLoginLabel = new System.Windows.Forms.Label();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.loginButton = new System.Windows.Forms.Button();
            this.exitAppBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.forgotLinkLabel = new System.Windows.Forms.LinkLabel();
            this.loginErrorLabel = new System.Windows.Forms.Label();
            this.loginDataSet = new AkhavanDatabaseSystem.LoginDataSet();
            this.loginBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loginTableAdapter = new AkhavanDatabaseSystem.LoginDataSetTableAdapters.LoginTableAdapter();
            this.tableAdapterManager = new AkhavanDatabaseSystem.LoginDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.userPictureBoz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // userPictureBoz
            // 
            this.userPictureBoz.Image = global::AkhavanDatabaseSystem.Properties.Resources.personLoginImg;
            this.userPictureBoz.Location = new System.Drawing.Point(57, 200);
            this.userPictureBoz.Margin = new System.Windows.Forms.Padding(2);
            this.userPictureBoz.Name = "userPictureBoz";
            this.userPictureBoz.Size = new System.Drawing.Size(200, 195);
            this.userPictureBoz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.userPictureBoz.TabIndex = 0;
            this.userPictureBoz.TabStop = false;
            // 
            // memberLoginLabel
            // 
            this.memberLoginLabel.AutoSize = true;
            this.memberLoginLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memberLoginLabel.Location = new System.Drawing.Point(319, 200);
            this.memberLoginLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.memberLoginLabel.Name = "memberLoginLabel";
            this.memberLoginLabel.Size = new System.Drawing.Size(201, 32);
            this.memberLoginLabel.TabIndex = 1;
            this.memberLoginLabel.Text = "Member Login";
            this.memberLoginLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameTextBox.ForeColor = System.Drawing.Color.Silver;
            this.usernameTextBox.Location = new System.Drawing.Point(324, 267);
            this.usernameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(194, 29);
            this.usernameTextBox.TabIndex = 2;
            this.usernameTextBox.Text = "Employee Id";
            this.usernameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.usernameTextBox.Enter += new System.EventHandler(this.usernameTextBox_Enter);
            this.usernameTextBox.Leave += new System.EventHandler(this.usernameTextBox_Leave);
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTextBox.ForeColor = System.Drawing.Color.Silver;
            this.passwordTextBox.Location = new System.Drawing.Point(324, 303);
            this.passwordTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(194, 29);
            this.passwordTextBox.TabIndex = 3;
            this.passwordTextBox.Text = "Password";
            this.passwordTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.passwordTextBox.Enter += new System.EventHandler(this.passwordTextBox_Enter);
            this.passwordTextBox.Leave += new System.EventHandler(this.passwordTextBox_Leave);
            // 
            // loginButton
            // 
            this.loginButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginButton.Location = new System.Drawing.Point(324, 352);
            this.loginButton.Margin = new System.Windows.Forms.Padding(2);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(193, 34);
            this.loginButton.TabIndex = 4;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // exitAppBtn
            // 
            this.exitAppBtn.BackColor = System.Drawing.Color.Red;
            this.exitAppBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitAppBtn.Location = new System.Drawing.Point(484, 2);
            this.exitAppBtn.Margin = new System.Windows.Forms.Padding(2);
            this.exitAppBtn.Name = "exitAppBtn";
            this.exitAppBtn.Size = new System.Drawing.Size(101, 34);
            this.exitAppBtn.TabIndex = 5;
            this.exitAppBtn.Text = "Exit App";
            this.exitAppBtn.UseVisualStyleBackColor = false;
            this.exitAppBtn.Click += new System.EventHandler(this.exitAppBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AkhavanDatabaseSystem.Properties.Resources.akhavanLogo;
            this.pictureBox1.Location = new System.Drawing.Point(183, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(233, 149);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // forgotLinkLabel
            // 
            this.forgotLinkLabel.AutoSize = true;
            this.forgotLinkLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgotLinkLabel.Location = new System.Drawing.Point(321, 400);
            this.forgotLinkLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.forgotLinkLabel.Name = "forgotLinkLabel";
            this.forgotLinkLabel.Size = new System.Drawing.Size(204, 16);
            this.forgotLinkLabel.TabIndex = 7;
            this.forgotLinkLabel.TabStop = true;
            this.forgotLinkLabel.Text = "Forgot Username/Password?";
            this.forgotLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.forgotLinkLabel_LinkClicked);
            // 
            // loginErrorLabel
            // 
            this.loginErrorLabel.AutoSize = true;
            this.loginErrorLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.loginErrorLabel.Location = new System.Drawing.Point(322, 242);
            this.loginErrorLabel.Name = "loginErrorLabel";
            this.loginErrorLabel.Size = new System.Drawing.Size(0, 18);
            this.loginErrorLabel.TabIndex = 10;
            // 
            // loginDataSet
            // 
            this.loginDataSet.DataSetName = "LoginDataSet";
            this.loginDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginBindingSource
            // 
            this.loginBindingSource.DataMember = "Login";
            this.loginBindingSource.DataSource = this.loginDataSet;
            // 
            // loginTableAdapter
            // 
            this.loginTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LoginTableAdapter = this.loginTableAdapter;
            this.tableAdapterManager.UpdateOrder = AkhavanDatabaseSystem.LoginDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // LogInUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.Controls.Add(this.loginErrorLabel);
            this.Controls.Add(this.forgotLinkLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exitAppBtn);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.usernameTextBox);
            this.Controls.Add(this.memberLoginLabel);
            this.Controls.Add(this.userPictureBoz);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "LogInUserControl";
            this.Size = new System.Drawing.Size(605, 536);
            ((System.ComponentModel.ISupportInitialize)(this.userPictureBoz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox userPictureBoz;
        private System.Windows.Forms.Label memberLoginLabel;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Button exitAppBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel forgotLinkLabel;
        private System.Windows.Forms.Label loginErrorLabel;
        private LoginDataSet loginDataSet;
        private System.Windows.Forms.BindingSource loginBindingSource;
        private LoginDataSetTableAdapters.LoginTableAdapter loginTableAdapter;
        private LoginDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}
